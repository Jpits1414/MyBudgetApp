package com.example.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ExpenseTracker extends AppCompatActivity {

    private static final int REQUEST_CODE_CALC = 1;
    private double foodTotal = 0;
    private double transportTotal = 0;
    private double entertainmentTotal = 0;
    private double electricTotal = 0;
    private double internetTotal = 0;

    private DatabaseReference databaseReference;
    private String userId = "user1"; // Replace this with FirebaseAuth UID if using authentication

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_expense_tracker);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseReference = FirebaseDatabase.getInstance().getReference("expenses").child(userId);

        loadTotalsFromFirebase();

        Button backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(v -> finish());

        Button logButton = findViewById(R.id.AddExpense);
        logButton.setOnClickListener(v -> {
            Intent intent = new Intent(ExpenseTracker.this, Calcu.class);
            Toast.makeText(getApplicationContext(), "Calculate your expenses now!", Toast.LENGTH_SHORT).show();
            startActivityForResult(intent, REQUEST_CODE_CALC);
        });

        Button resetButton = findViewById(R.id.reset_button);
        resetButton.setOnClickListener(v -> {
            databaseReference.removeValue().addOnCompleteListener(task -> {
                foodTotal = 0;
                transportTotal = 0;
                entertainmentTotal = 0;
                electricTotal = 0;
                internetTotal = 0;

                updateTextViews();

                Intent resetIntent = new Intent();
                resetIntent.putExtra("reset", true);
                setResult(RESULT_OK, resetIntent);
                finish();

                Toast.makeText(this, "All expenses have been reset!", Toast.LENGTH_SHORT).show();
            });
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_CALC && resultCode == RESULT_OK && data != null) {
            if (data.hasExtra("foodAmount")) {
                double foodAmount = data.getDoubleExtra("foodAmount", 0);
                foodTotal += foodAmount;
            }
            if (data.hasExtra("transportAmount")) {
                double transportAmount = data.getDoubleExtra("transportAmount", 0);
                transportTotal += transportAmount;
            }
            if (data.hasExtra("entertainmentAmount")) {
                double entertainmentAmount = data.getDoubleExtra("entertainmentAmount", 0);
                entertainmentTotal += entertainmentAmount;
            }
            if (data.hasExtra("electricAmount")) {
                double electricAmount = data.getDoubleExtra("electricAmount", 0);
                electricTotal += electricAmount;
            }
            if (data.hasExtra("internetAmount")) {
                double internetAmount = data.getDoubleExtra("internetAmount", 0);
                internetTotal += internetAmount;
            }

            updateTextViews();
            saveTotalsToFirebase();

            Intent intent = new Intent();
            intent.putExtra("foodAmount", foodTotal);
            intent.putExtra("transportAmount", transportTotal);
            intent.putExtra("entertainmentAmount", entertainmentTotal);
            intent.putExtra("electricAmount", electricTotal);
            intent.putExtra("internetAmount", internetTotal);
            setResult(RESULT_OK, intent);
        }
    }

    private void saveTotalsToFirebase() {
        databaseReference.child("foodTotal").setValue(foodTotal);
        databaseReference.child("transportTotal").setValue(transportTotal);
        databaseReference.child("entertainmentTotal").setValue(entertainmentTotal);
        databaseReference.child("electricTotal").setValue(electricTotal);
        databaseReference.child("internetTotal").setValue(internetTotal);
    }

    private void loadTotalsFromFirebase() {
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    foodTotal = snapshot.child("foodTotal").getValue(Double.class) != null ? snapshot.child("foodTotal").getValue(Double.class) : 0;
                    transportTotal = snapshot.child("transportTotal").getValue(Double.class) != null ? snapshot.child("transportTotal").getValue(Double.class) : 0;
                    entertainmentTotal = snapshot.child("entertainmentTotal").getValue(Double.class) != null ? snapshot.child("entertainmentTotal").getValue(Double.class) : 0;
                    electricTotal = snapshot.child("electricTotal").getValue(Double.class) != null ? snapshot.child("electricTotal").getValue(Double.class) : 0;
                    internetTotal = snapshot.child("internetTotal").getValue(Double.class) != null ? snapshot.child("internetTotal").getValue(Double.class) : 0;

                    updateTextViews();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(ExpenseTracker.this, "Failed to load data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateTextViews() {
        ((TextView) findViewById(R.id.food_bill)).setText("₱" + (int) foodTotal);
        ((TextView) findViewById(R.id.transport_bill)).setText("₱" + (int) transportTotal);
        ((TextView) findViewById(R.id.entertainment_bill)).setText("₱" + (int) entertainmentTotal);
        ((TextView) findViewById(R.id.electrics_bill)).setText("₱" + (int) electricTotal);
        ((TextView) findViewById(R.id.internets_bill)).setText("₱" + (int) internetTotal);
    }
}
