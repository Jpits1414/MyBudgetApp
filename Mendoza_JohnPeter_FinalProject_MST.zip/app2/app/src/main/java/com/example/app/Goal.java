package com.example.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Goal extends AppCompatActivity {

    // Declare variables
    EditText editGoals;
    Button enterButton, foodButton, transportButton, entertainmentButton, electricButton, internetButton;
    TextView goals, amountTextView;
    String selectedCategory = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_goal);

        // Adjust window padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editGoals = findViewById(R.id.edit_goals);
        enterButton = findViewById(R.id.enter);
        foodButton = findViewById(R.id.food);
        transportButton = findViewById(R.id.Transport);
        entertainmentButton = findViewById(R.id.Entertainment);
        electricButton = findViewById(R.id.ELECTRIC);
        internetButton = findViewById(R.id.INTERNET);
        goals = findViewById(R.id.goals);
        amountTextView = findViewById(R.id.amount_1);

        foodButton.setOnClickListener(v -> {
            selectedCategory = "food";
            goals.setText("Food");
        });

        transportButton.setOnClickListener(v -> {
            selectedCategory = "transport";
            goals.setText("Transport");
        });

        entertainmentButton.setOnClickListener(v -> {
            selectedCategory = "entertainment";
            goals.setText("Entertainment");
        });

        electricButton.setOnClickListener(v -> {
            selectedCategory = "electric";
            goals.setText("Electric");
        });

        internetButton.setOnClickListener(v -> {
            selectedCategory = "internet";
            goals.setText("Internet");
        });

        enterButton.setOnClickListener(v -> {
            String goalAmount = editGoals.getText().toString().trim();

            if (!goalAmount.isEmpty() && !selectedCategory.isEmpty()) {
                amountTextView.setText(goalAmount);

                Intent resultIntent = new Intent();
                resultIntent.putExtra("goal", goalAmount);
                resultIntent.putExtra("category", selectedCategory);
                setResult(RESULT_OK, resultIntent);
                finish();
            } else {
                Toast.makeText(Goal.this, "Please select a category and enter a goal.", Toast.LENGTH_SHORT).show();
            }
        });

        Button backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(v -> finish());
    }
}
