package com.example.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Calcu extends AppCompatActivity {

    private TextView viewComputation;
    private StringBuilder currentInput;
    private double currentAmount = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_calcu);

        // Set up window insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize computation view and input holder
        viewComputation = findViewById(R.id.viewcomputation);
        currentInput = new StringBuilder();

        // Number buttons
        findViewById(R.id.calcu_0).setOnClickListener(v -> appendToComputation("0"));
        findViewById(R.id.calcu_1).setOnClickListener(v -> appendToComputation("1"));
        findViewById(R.id.calcu_2).setOnClickListener(v -> appendToComputation("2"));
        findViewById(R.id.calcu_3).setOnClickListener(v -> appendToComputation("3"));
        findViewById(R.id.calcu_4).setOnClickListener(v -> appendToComputation("4"));
        findViewById(R.id.calcu_5).setOnClickListener(v -> appendToComputation("5"));
        findViewById(R.id.calcu_6).setOnClickListener(v -> appendToComputation("6"));
        findViewById(R.id.calcu_7).setOnClickListener(v -> appendToComputation("7"));
        findViewById(R.id.calcu_8).setOnClickListener(v -> appendToComputation("8"));
        findViewById(R.id.calcu_9).setOnClickListener(v -> appendToComputation("9"));

        // Operator buttons
        findViewById(R.id.calcu_plus).setOnClickListener(v -> appendToComputation("+"));
        findViewById(R.id.calcu_minus).setOnClickListener(v -> appendToComputation("-"));
        findViewById(R.id.calcu_times).setOnClickListener(v -> appendToComputation("x"));
        findViewById(R.id.calcu_divide).setOnClickListener(v -> appendToComputation("/"));

        // Equal button to compute the result
        findViewById(R.id.calcu_equal).setOnClickListener(v -> {
            String result = computeResult(currentInput.toString());
            viewComputation.setText(result);
            currentInput.setLength(0);
        });

        // Expense Category Buttons
        findViewById(R.id.food).setOnClickListener(v -> {
            double foodAmount = calculateAmount();
            currentAmount = foodAmount;
            updateExpense("foodAmount", currentAmount);
        });

        findViewById(R.id.Transport).setOnClickListener(v -> {
            double transportAmount = calculateAmount();
            currentAmount = transportAmount;
            updateExpense("transportAmount", currentAmount);
        });

        findViewById(R.id.Entertainment).setOnClickListener(v -> {
            double entertainmentAmount = calculateAmount();
            currentAmount = entertainmentAmount;
            updateExpense("entertainmentAmount", currentAmount);
        });

        findViewById(R.id.ELECTRIC).setOnClickListener(v -> {
            double electricAmount = calculateAmount();
            currentAmount = electricAmount;
            updateExpense("electricAmount", currentAmount);
        });

        findViewById(R.id.INTERNET).setOnClickListener(v -> {
            double internetAmount = calculateAmount();
            currentAmount = internetAmount;
            updateExpense("internetAmount", currentAmount);
        });

        // Delete (Backspace) button
        findViewById(R.id.enter).setOnClickListener(v -> {
            if (currentInput.length() > 0) {
                currentInput.deleteCharAt(currentInput.length() - 1);
                viewComputation.setText(currentInput.toString());
            }
        });

        // Back button
        Button backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(v -> finish());
    }

    private void appendToComputation(String value) {
        currentInput.append(value);
        viewComputation.setText(currentInput.toString());
    }

    private String computeResult(String input) {
        try {
            input = input.replace("x", "*").replace("/", "/");
            String[] parts = input.split("(?=[-+*/])|(?<=[-+*/])");
            double result = 0;
            String operator = "";
            for (String part : parts) {
                if (part.equals("+") || part.equals("-") || part.equals("x") || part.equals("/")) {
                    operator = part;
                } else {
                    double num = Double.parseDouble(part);
                    if (operator.equals("+")) {
                        result += num;
                    } else if (operator.equals("-")) {
                        result -= num;
                    } else if (operator.equals("x")) {
                        result *= num;
                    } else if (operator.equals("/")) {
                        result /= num;
                    } else {
                        result = num;
                    }
                }
            }

            return (result % 1 == 0) ? "₱" + (int) result : "₱" + result;
        } catch (Exception e) {
            return "Error";
        }
    }

    private double calculateAmount() {
        String resultText = viewComputation.getText().toString();
        if (!resultText.isEmpty()) {
            return Double.parseDouble(resultText.replace("₱", ""));
        }
        return 0.0;
    }

    private void updateExpense(String key, double amount) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra(key, amount);
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}
