package com.example.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    EditText username, password;
    DatabaseReference databaseUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Toast.makeText(getApplicationContext(), "Welcome!", Toast.LENGTH_SHORT).show();

        username = findViewById(R.id.Username);
        password = findViewById(R.id.Pass);
        Button loginButton = findViewById(R.id.LoginButton);

        // Firebase reference to "users" node
        databaseUsers = FirebaseDatabase.getInstance().getReference("users");

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredEmail = username.getText().toString().trim();
                String enteredPassword = password.getText().toString().trim();

                if (!enteredEmail.isEmpty() && !enteredPassword.isEmpty()) {

                    databaseUsers.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot snapshot) {
                            boolean found = false;

                            for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                                CreateAccount.User user = userSnapshot.getValue(CreateAccount.User.class);
                                if (user != null && enteredEmail.equals(user.email) && enteredPassword.equals(user.password)) {
                                    found = true;
                                    break;
                                }
                            }

                            if (found) {
                                Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(MainActivity.this, "Invalid Email or Password", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError error) {
                            Toast.makeText(MainActivity.this, "Database error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

                } else {
                    Toast.makeText(MainActivity.this, "Please enter both email and password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button Create = findViewById(R.id.CreateAccountButton);
        Create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CreateAccount.class);
                Toast.makeText(getApplicationContext(), "Create Account!", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });
    }
}
