package com.example.app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class spendingalerts extends AppCompatActivity {

    TextView notificationTransport, notificationFood, notificationEntertainment, notificationElectric, notificationInternet;
    TextView totalTextViewTransport, totalTextViewFood, totalTextViewEntertainment, totalTextViewElectric, totalTextViewInternet;

    // Firebase references
    DatabaseReference goalsRef;
    DatabaseReference expensesRef;

    private String userId = "user1"; // Replace with user id if needed

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_spendingalerts);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(v -> finish());


        notificationTransport = findViewById(R.id.notification_transport);
        notificationFood = findViewById(R.id.notification_food);
        notificationEntertainment = findViewById(R.id.notification_entertainment);
        notificationElectric = findViewById(R.id.notification_electric);
        notificationInternet = findViewById(R.id.notification_internet);

        totalTextViewTransport = findViewById(R.id.Total);
        totalTextViewFood = findViewById(R.id.Total1);
        totalTextViewEntertainment = findViewById(R.id.total2);
        totalTextViewElectric = findViewById(R.id.total3);
        totalTextViewInternet = findViewById(R.id.total4);

        goalsRef = FirebaseDatabase.getInstance().getReference("budget_goals");
        expensesRef = FirebaseDatabase.getInstance().getReference("expenses").child(userId);

        // Load both budget goals and expenses then update UI
        loadDataAndUpdateUI();
    }

    private void loadDataAndUpdateUI() {
        // First get goals
        goalsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot goalsSnapshot) {
                if (goalsSnapshot.exists()) {
                    expensesRef.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot expensesSnapshot) {
                            if (expensesSnapshot.exists()) {
                                checkAndShowAlerts(goalsSnapshot, expensesSnapshot);
                            } else {
                                // No expenses yet, just show goals with no alerts
                                setTotalsFromGoals(goalsSnapshot);
                                clearAlerts();
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError error) {
                            clearAlerts();
                        }
                    });
                } else {
                    clearAlerts();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                clearAlerts();
            }
        });
    }

    private void checkAndShowAlerts(DataSnapshot goalsSnapshot, DataSnapshot expensesSnapshot) {
        double goalTransport = parseDouble(goalsSnapshot.child("transport").getValue(String.class));
        double goalFood = parseDouble(goalsSnapshot.child("food").getValue(String.class));
        double goalEntertainment = parseDouble(goalsSnapshot.child("entertainment").getValue(String.class));
        double goalElectric = parseDouble(goalsSnapshot.child("electric").getValue(String.class));
        double goalInternet = parseDouble(goalsSnapshot.child("internet").getValue(String.class));

        double expenseTransport = expensesSnapshot.child("transportTotal").getValue(Double.class) != null ? expensesSnapshot.child("transportTotal").getValue(Double.class) : 0;
        double expenseFood = expensesSnapshot.child("foodTotal").getValue(Double.class) != null ? expensesSnapshot.child("foodTotal").getValue(Double.class) : 0;
        double expenseEntertainment = expensesSnapshot.child("entertainmentTotal").getValue(Double.class) != null ? expensesSnapshot.child("entertainmentTotal").getValue(Double.class) : 0;
        double expenseElectric = expensesSnapshot.child("electricTotal").getValue(Double.class) != null ? expensesSnapshot.child("electricTotal").getValue(Double.class) : 0;
        double expenseInternet = expensesSnapshot.child("internetTotal").getValue(Double.class) != null ? expensesSnapshot.child("internetTotal").getValue(Double.class) : 0;

        setTotals(expenseTransport, expenseFood, expenseEntertainment, expenseElectric, expenseInternet);

        // 80% threshold check
        checkAlertForCategory(expenseTransport, goalTransport, notificationTransport);
        checkAlertForCategory(expenseFood, goalFood, notificationFood);
        checkAlertForCategory(expenseEntertainment, goalEntertainment, notificationEntertainment);
        checkAlertForCategory(expenseElectric, goalElectric, notificationElectric);
        checkAlertForCategory(expenseInternet, goalInternet, notificationInternet);
    }

    private void setTotals(double transport, double food, double entertainment, double electric, double internet) {
        totalTextViewTransport.setText("₱" + (int) transport);
        totalTextViewFood.setText("₱" + (int) food);
        totalTextViewEntertainment.setText("₱" + (int) entertainment);
        totalTextViewElectric.setText("₱" + (int) electric);
        totalTextViewInternet.setText("₱" + (int) internet);
    }

    private void setTotalsFromGoals(DataSnapshot goalsSnapshot) {
        totalTextViewTransport.setText("₱" + goalsSnapshot.child("transport").getValue(String.class));
        totalTextViewFood.setText("₱" + goalsSnapshot.child("food").getValue(String.class));
        totalTextViewEntertainment.setText("₱" + goalsSnapshot.child("entertainment").getValue(String.class));
        totalTextViewElectric.setText("₱" + goalsSnapshot.child("electric").getValue(String.class));
        totalTextViewInternet.setText("₱" + goalsSnapshot.child("internet").getValue(String.class));
    }

    private void checkAlertForCategory(double expense, double goal, TextView notificationView) {
        if (goal > 0 && expense >= 0.8 * goal) {
            notificationView.setText("You're close to your limit");
            notificationView.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        } else {
            notificationView.setText("• You're within your budget");
            notificationView.setTextColor(getResources().getColor(android.R.color.darker_gray));
        }
    }

    private void clearAlerts() {
        notificationTransport.setText("");
        notificationFood.setText("");
        notificationEntertainment.setText("");
        notificationElectric.setText("");
        notificationInternet.setText("");
    }

    private double parseDouble(String s) {
        try {
            return Double.parseDouble(s);
        } catch (Exception e) {
            return 0;
        }
    }
}
