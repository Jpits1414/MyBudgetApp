package com.example.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class budgetgoal extends AppCompatActivity {

    TextView food, transport, entertainment, electric, internet;
    DatabaseReference goalsRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_budgetgoal);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        food = findViewById(R.id.food_bill);
        transport = findViewById(R.id.transport_bill);
        entertainment = findViewById(R.id.entertainment_bill);
        electric = findViewById(R.id.electrics_bill);
        internet = findViewById(R.id.internets_bill);

        // Reference to Firebase path: "budget_goals"
        goalsRef = FirebaseDatabase.getInstance().getReference("budget_goals");

        // Load all saved budget goals from Firebase
        goalsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    food.setText("₱" + snapshot.child("food").getValue(String.class));
                    transport.setText("₱" + snapshot.child("transport").getValue(String.class));
                    entertainment.setText("₱" + snapshot.child("entertainment").getValue(String.class));
                    electric.setText("₱" + snapshot.child("electric").getValue(String.class));
                    internet.setText("₱" + snapshot.child("internet").getValue(String.class));
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(budgetgoal.this, "Failed to load data", Toast.LENGTH_SHORT).show();
            }
        });

        Button backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(v -> finish());

        Button goalButton = findViewById(R.id.new_goal);
        goalButton.setOnClickListener(v -> {
            Intent intent = new Intent(budgetgoal.this, Goal.class);
            Toast.makeText(getApplicationContext(), "Set a new goal now!", Toast.LENGTH_SHORT).show();
            startActivityForResult(intent, 1);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            String goal = data.getStringExtra("goal");
            String category = data.getStringExtra("category");

            if (goal != null && category != null) {
                // Save to Firebase
                goalsRef.child(category).setValue(goal);

                // Update the UI
                switch (category) {
                    case "food":
                        food.setText("₱" + goal);
                        break;
                    case "transport":
                        transport.setText("₱" + goal);
                        break;
                    case "entertainment":
                        entertainment.setText("₱" + goal);
                        break;
                    case "electric":
                        electric.setText("₱" + goal);
                        break;
                    case "internet":
                        internet.setText("₱" + goal);
                        break;
                }
            }
        }
    }
}
