package com.example.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DashboardActivity extends AppCompatActivity {

    EditText setIncomeEditText;
    TextView incomeTextView;
    Button incomeButton;

    DatabaseReference userRef;

    // Track total expenses loaded from Firebase
    private int totalExpenses = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Toast.makeText(getApplicationContext(), "Log In Successful!", Toast.LENGTH_SHORT).show();
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        setIncomeEditText = findViewById(R.id.set_income);
        incomeTextView = findViewById(R.id.inc);
        incomeButton = findViewById(R.id.incomeButton);

        userRef = FirebaseDatabase.getInstance().getReference("users").child("default");

        loadIncomeBalance();

        incomeButton.setOnClickListener(v -> {
            String inputIncome = setIncomeEditText.getText().toString();

            if (!inputIncome.isEmpty()) {
                int incomeValue = (int) Double.parseDouble(inputIncome);
                String formattedIncome = "₱" + incomeValue;

                incomeTextView.setText(formattedIncome);
                TextView balanceTextView = findViewById(R.id.textView);
                balanceTextView.setText(formattedIncome);

                // When income is set, reset expense and balance accordingly
                totalExpenses = 0;  // Reset total expenses when income resets
                saveIncomeBalance(incomeValue, incomeValue, 0);

                Toast.makeText(DashboardActivity.this, "Income Added!", Toast.LENGTH_SHORT).show();
                setIncomeEditText.setText("");
            } else {
                Toast.makeText(DashboardActivity.this, "Please enter an income amount", Toast.LENGTH_SHORT).show();
            }
        });

        ImageButton expenseTrackerButton = findViewById(R.id.expensetrack);
        expenseTrackerButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, ExpenseTracker.class);
            Toast.makeText(getApplicationContext(), "Opening Expense Tracker...", Toast.LENGTH_SHORT).show();
            startActivityForResult(intent, 1);
        });

        ImageButton budgetGoalButton = findViewById(R.id.bud);
        budgetGoalButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, budgetgoal.class);
            Toast.makeText(getApplicationContext(), "Opening Budget Goal...", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });

        ImageButton spendAlertButton = findViewById(R.id.spend);
        spendAlertButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, spendingalerts.class);
            Toast.makeText(getApplicationContext(), "Opening Spending Alerts...", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });

        ImageButton notificationButton = findViewById(R.id.notification);
        notificationButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, billreminders.class);
            Toast.makeText(getApplicationContext(), "Opening Bill Reminders...", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });

        ImageButton reportButton = findViewById(R.id.rep);
        reportButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, reports.class);
            Toast.makeText(getApplicationContext(), "Opening Reports...", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        });

        // *** LOGOUT BUTTON ADDITION ***
        Button logoutButton = findViewById(R.id.Logout);
        logoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            Toast.makeText(DashboardActivity.this, "Logged out successfully", Toast.LENGTH_SHORT).show();
        });
    }

    private void saveIncomeBalance(int income, int balance, int expense) {
        userRef.child("income").setValue(income);
        userRef.child("balance").setValue(balance);
        userRef.child("expense").setValue(expense);
    }

    private void loadIncomeBalance() {
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                int income = snapshot.child("income").getValue(Integer.class) != null ? snapshot.child("income").getValue(Integer.class) : 0;
                int balance = snapshot.child("balance").getValue(Integer.class) != null ? snapshot.child("balance").getValue(Integer.class) : 0;
                int expense = snapshot.child("expense").getValue(Integer.class) != null ? snapshot.child("expense").getValue(Integer.class) : 0;

                incomeTextView.setText("₱" + income);
                ((TextView) findViewById(R.id.textView)).setText("₱" + balance);
                ((TextView) findViewById(R.id.exp)).setText("₱" + expense);

                totalExpenses = expense;  // Store loaded total expenses to calculate diff later
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(DashboardActivity.this, "Failed to load data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            // Calculate the new total expenses from returned data
            double newTotalExpenses = data.getDoubleExtra("foodAmount", 0) +
                    data.getDoubleExtra("transportAmount", 0) +
                    data.getDoubleExtra("entertainmentAmount", 0) +
                    data.getDoubleExtra("electricAmount", 0) +
                    data.getDoubleExtra("internetAmount", 0);

            int newTotalExpensesInt = (int) newTotalExpenses;

            // Calculate the difference in expenses (new expense added since last update)
            int expenseDifference = newTotalExpensesInt - totalExpenses;

            // Update totalExpenses tracker
            totalExpenses = newTotalExpensesInt;

            TextView expenseTextView = findViewById(R.id.exp);
            expenseTextView.setText("₱" + totalExpenses);

            TextView balanceTextView = findViewById(R.id.textView);
            String currentBalanceStr = balanceTextView.getText().toString().replace("₱", "");
            int currentBalance = Integer.parseInt(currentBalanceStr);

            // Subtract only the new expenses difference
            int updatedBalance = currentBalance - expenseDifference;

            balanceTextView.setText("₱" + updatedBalance);

            // Update Firebase values
            userRef.child("balance").setValue(updatedBalance);
            userRef.child("expense").setValue(totalExpenses);
        }
    }
}
