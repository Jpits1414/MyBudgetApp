package com.example.app;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class reports extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private String userId = "user1"; // Replace this with FirebaseAuth UID if using authentication

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseReference = FirebaseDatabase.getInstance().getReference("expenses").child(userId);

        Button backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(v -> finish());

        PieChart pieChart = findViewById(R.id.pieChart);
        ListView listView = findViewById(R.id.listViewExpenses);

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    float food = snapshot.child("foodTotal").getValue(Float.class) != null ? snapshot.child("foodTotal").getValue(Float.class) : 0;
                    float transport = snapshot.child("transportTotal").getValue(Float.class) != null ? snapshot.child("transportTotal").getValue(Float.class) : 0;
                    float entertainment = snapshot.child("entertainmentTotal").getValue(Float.class) != null ? snapshot.child("entertainmentTotal").getValue(Float.class) : 0;
                    float electric = snapshot.child("electricTotal").getValue(Float.class) != null ? snapshot.child("electricTotal").getValue(Float.class) : 0;
                    float internet = snapshot.child("internetTotal").getValue(Float.class) != null ? snapshot.child("internetTotal").getValue(Float.class) : 0;

                    float total = food + transport + entertainment + electric + internet;

                    if (total == 0) {
                        Toast.makeText(reports.this, "No expense data to show!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    ArrayList<PieEntry> entries = new ArrayList<>();
                    if (food > 0) entries.add(new PieEntry((food / total) * 100f, "Food"));
                    if (transport > 0) entries.add(new PieEntry((transport / total) * 100f, "Transport"));
                    if (entertainment > 0) entries.add(new PieEntry((entertainment / total) * 100f, "Entertainment"));
                    if (electric > 0) entries.add(new PieEntry((electric / total) * 100f, "Electric"));
                    if (internet > 0) entries.add(new PieEntry((internet / total) * 100f, "Internet"));

                    PieDataSet dataSet = new PieDataSet(entries, "Expense Breakdown");
                    dataSet.setColors(new int[]{
                            Color.parseColor("#FF6384"),  // Food
                            Color.parseColor("#36A2EB"),  // Transport
                            Color.parseColor("#FFCE56"),  // Entertainment
                            Color.parseColor("#FFA726"),  // Electric
                            Color.parseColor("#66BB6A")   // Internet
                    });
                    dataSet.setValueTextColor(Color.WHITE);
                    dataSet.setValueTextSize(12f);
                    dataSet.setValueFormatter(new ValueFormatter() {
                        @Override
                        public String getFormattedValue(float value) {
                            return String.format("%.1f%%", value);
                        }
                    });

                    PieData pieData = new PieData(dataSet);
                    pieChart.setData(pieData);
                    pieChart.setUsePercentValues(true);
                    pieChart.getDescription().setEnabled(false);
                    pieChart.setDrawHoleEnabled(true);
                    pieChart.setHoleRadius(30f);
                    pieChart.setTransparentCircleRadius(35f);
                    pieChart.setEntryLabelColor(Color.BLACK);
                    pieChart.setEntryLabelTextSize(12f);

                    Legend legend = pieChart.getLegend();
                    legend.setEnabled(true);
                    legend.setTextSize(12f);
                    legend.setFormSize(10f);

                    pieChart.invalidate();

                    ArrayList<String> expenseItems = new ArrayList<>();
                    if (food > 0) expenseItems.add("Food: ₱" + (int) food);
                    if (transport > 0) expenseItems.add("Transport: ₱" + (int) transport);
                    if (entertainment > 0) expenseItems.add("Entertainment: ₱" + (int) entertainment);
                    if (electric > 0) expenseItems.add("Electric: ₱" + (int) electric);
                    if (internet > 0) expenseItems.add("Internet: ₱" + (int) internet);

                    ArrayAdapter<String> adapter = new ArrayAdapter<>(reports.this, android.R.layout.simple_list_item_1, expenseItems);
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(reports.this, "Failed to load data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
